#!/usr/bin/env python
# -*- coding: utf-8 -*-
with open("caderno.txt") as f:
      print (len(f.readlines()))
